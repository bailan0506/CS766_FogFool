import torch
import torch.nn as nn
import torchvision.datasets as datasets
from torch.autograd import Variable
import torchvision.transforms as transforms
import torchvision.models as models
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import time



#DNN,return index
def F(img_var):
    #Output probability vector
    output=alexnet(img_var)
    #find the largest probability
    #print output.data	
    val,ind=torch.max(output.data,1)
    #print val
    #print  ind
    return ind[0,0]

#F^l_S, return the prob of label l (ind), return a Variable(data: 1*1 tensor)
def F_l(img_var,ind):
    #Output probability vector
    output=alexnet(img_var)
    #softmax
    """max_val,max_ind=torch.max(output.data,1)
    min_val,min_ind=torch.min(output.data,1)
    output_normalize=torch.add(output.data,-min_val[0,0])
    scale=torch.sum(output_normalize)
    print scale
    output_normalize=torch.mul(output_normalize,1/scale)"""
    m=nn.Softmax()
    output_softmax=m(output)
    output_l=output_softmax.data[0,ind]
    #print output_l
    return output_l
    
    
    

#grad, F^l_s
def gradF_l(img_var,ind):
    m=nn.Softmax()
    F=(m(alexnet(img_var)))[:,ind]
    F.backward()
    #print img_var.grad
    return img_var.grad
    
    
    
def NFMinNorm(x0,sigma,maxIter):
    check_iter=3
    x0_norm=torch.norm(x0)
    img=torch.Tensor(x0)
    img_var=Variable(img,requires_grad=True)
    l=F(img_var)
    d=torch.FloatTensor(x0.size()).zero_()
    cnt=0
    for i in range(0,maxIter):
        img_var=Variable(img,requires_grad=True)
        """a=0
        a+=torch.mean(img_var)
        a.backward()
        img_var.grad.data.zero_()"""
        F_val=F_l(img_var,l) #F^l_s(x_i), Variable with data size 1
        grad=gradF_l(img_var,l) #grad F^l_s(x_i), tensor
        grad_norm=(torch.norm(grad).data)[0]
        #print grad_norm
        val=-F_val/(grad_norm*grad_norm)
        #print val
        d_i=torch.mul(grad,val) 
        di_norm=(torch.norm(d_i).data)[0]
        #d_i=sigma*x0_norm*d_i/torch.norm(d_i)
        d_i=torch.mul(d_i,x0_norm*sigma/di_norm)
        #PRINT img
        #print d_i
        img=img+d_i.data
        d=d+d_i.data
        cnt=cnt+1
        if cnt==check_iter:
            cnt=0
            if F(Variable(img))!=l:
                break
    success=(F(Variable(img))!=l)
    return d,img,success	



# The Nesterov's Accelerated Gradient Descent Algorithm to solve the following problem:
# min 1/2 ||F^l(x+img)||_2^2 + 1/2 alpha * ||x||_2^2, where x is the noise
# At each step, we perform the following step
# y_{s+1} = x_s - sigma [ F^l grad F^l + alpha x ]  
# x_{s+1} = (1-gamma_s) y_{s+1} + gamma_s y_s
# gamma_s = (1-lambda_s)/(lambda_{s+1} )
# lambda_0 = 0
# lambda_s = (1+sqrt(1+4 lambda_{s-1}^2 ) )/(2);
def NesterovGD(x0,sigma,alpha,maxIter):
    x0_norm=torch.norm(x0)
    img=torch.Tensor(x0)
    img_var=Variable(img,requires_grad=True)
    l=F(img_var)
    d=torch.FloatTensor(x0.size()).zero_()
    x = Variable(d)
    lambda_s = 0
    lambda_s_next = (1+np.sqrt(1+4*lambda_s*lambda_s ) )/(2)
    #print(lambda_s_next)
    gamma = (1-lambda_s)/lambda_s_next;
    yLast = x
    y = yLast
    for i in range(0,maxIter):
	# Preprocessing
        img_var=Variable(img,requires_grad=True)
        """a=0
        a+=torch.mean(img_var)
        a.backward()
        img_var.grad.data.zero_()"""
        # Compute the grad and the func value.
        F_val=F_l(img_var,l) #F^l_s(x_i), Variable with data size 1
        grad=gradF_l(img_var,l) #grad F^l_s(x_i), tensor
        grad_norm=(torch.norm(grad).data)[0]
        # Compute y_s
        # print(y)
        temp = y
        temp1 = torch.mul(x,alpha)
        #print(temp1)
        temp2 = torch.mul(grad,F_val)
        #print(temp2)
        temp3 = temp1 + temp2
        #print(temp3)
        y = x - torch.mul(temp3,sigma)	
        #y = x - torch.mul((torch.mul(grad,F_val) + torch.mul(x,alpha) ),sigma)
        #print('Finish y')
        # Compute x
        xold = x
        #print "Finish xold"
        #print (1-gamma)
        x = torch.mul(y, (1-gamma)) + torch.mul(yLast,gamma)
        #print (x)
        # Update gamma, lambda, and ylast
        yLast = temp
        temp = (1+np.sqrt(1+4 * lambda_s_next*lambda_s_next ) )/(2);
        lambda_s = lambda_s_next
        lambda_s_next = temp
        gamma = (1-lambda_s)/lambda_s_next
        # Update the image
        d_i = x-xold
        img=img+d_i.data
        d=d+d_i.data
        if F(Variable(img))!=l:
            break
    success=(F(Variable(img))!=l)
    return d,img,success


# This is Localfool for specific targeted attacks.
# The Nesterov's Accelerated Gradient Descent Algorithm to solve the following problem:
# min -1/2 ||F^l(x+img)||_2^2 + 1/2 alpha * ||x||_2^2, where x is the noise
# At each step, we perform the following step
# y_{s+1} = x_s - sigma [ F^l grad F^l + alpha x ]  
# x_{s+1} = (1-gamma_s) y_{s+1} + gamma_s y_s
# gamma_s = (1-lambda_s)/(lambda_{s+1} )
# lambda_0 = 0
# lambda_s = (1+sqrt(1+4 lambda_{s-1}^2 ) )/(2);
def NesterovGDTarget(x0,sigma,alpha,maxIter,Target):
    x0_norm=torch.norm(x0)
    img=torch.Tensor(x0)
    img_var=Variable(img,requires_grad=True)
    l= Target
    #F(img_var)
    d=torch.FloatTensor(x0.size()).zero_()
    x = Variable(d)
    lambda_s = 0
    lambda_s_next = (1+np.sqrt(1+4*lambda_s*lambda_s ) )/(2)
    #print(lambda_s_next)
    gamma = (1-lambda_s)/lambda_s_next;
    yLast = x
    y = yLast
    for i in range(0,maxIter):
	# Preprocessing
        img_var=Variable(img,requires_grad=True)
        """a=0
        a+=torch.mean(img_var)
        a.backward()
        img_var.grad.data.zero_()"""
        # Compute the grad and the func value.
        F_val=F_l(img_var,l)#-1 #F^l_s(x_i), Variable with data size 1
        print (F_val)
        grad=torch.mul(gradF_l(img_var,l),-1) #grad F^l_s(x_i), tensor
        grad_norm=(torch.norm(grad).data)[0]
        # Compute y_s
        # print(y)
        temp = y
        temp1 = torch.mul(x,alpha)
        #print(temp1)
        temp2 = torch.mul(grad,F_val)
        #print(temp2)
        temp3 = temp1 + temp2
        #print(temp3)
        y = x - torch.mul(temp3,sigma)	
        #y = x - torch.mul((torch.mul(grad,F_val) + torch.mul(x,alpha) ),sigma)
        #print('Finish y')
        # Compute x
        xold = x
        #print "Finish xold"
        print (1-gamma)
        x = torch.mul(y, (1-gamma)) + torch.mul(yLast,gamma)
        #print (x)
        # Update gamma, lambda, and ylast
        yLast = temp
        temp = (1+np.sqrt(1+4 * lambda_s_next*lambda_s_next ) )/(2);
        lambda_s = lambda_s_next
        lambda_s_next = temp
        gamma = (1-lambda_s)/lambda_s_next
        # Update the image
        d_i = x-xold
        img=img+d_i.data
        d=d+d_i.data
    return d,img



# This is Localfool for specific targeted attacks.
# The Gradient Descent Algorithm to solve the following problem:
# min -1/2 ||F^l(x+img)||_2^2 + 1/2 alpha * ||x||_2^2, where x is the noise
# At each step, we perform the following step
# y_{s+1} = x_s - sigma [ F^l grad F^l + alpha x ]  
# x_{s+1} = (1-gamma_s) y_{s+1} + gamma_s y_s
# gamma_s = (1-lambda_s)/(lambda_{s+1} )
# lambda_0 = 0
# lambda_s = (1+sqrt(1+4 lambda_{s-1}^2 ) )/(2);
def GDTarget(x0,sigma,alpha,maxIter,Target):
    x0_norm=torch.norm(x0)
    img=torch.Tensor(x0)
    img_var=Variable(img,requires_grad=True)
    l= Target
    #F(img_var)
    d=torch.FloatTensor(x0.size()).zero_()
    x = Variable(d)
    lambda_s = 0
    lambda_s_next = (1+np.sqrt(1+4*lambda_s*lambda_s ) )/(2)
    #print(lambda_s_next)
    gamma = (1-lambda_s)/lambda_s_next;
    yLast = x
    y = yLast
    for i in range(0,maxIter):
	# Preprocessing
        img_var=Variable(img,requires_grad=True)
        """a=0
        a+=torch.mean(img_var)
        a.backward()
        img_var.grad.data.zero_()"""
        # Compute the grad and the func value.
        F_val=F_l(img_var,l)-1 #F^l_s(x_i), Variable with data size 1
        print (F_val)
        grad=torch.mul(gradF_l(img_var,l),1) #grad F^l_s(x_i), tensor
        grad_norm=(torch.norm(grad).data)[0]
        # Compute y_s
        # print(y)
        temp = y
        temp1 = torch.mul(x,alpha)
        #print(temp1)
        temp2 = torch.mul(grad,F_val)
        #print(temp2)
        temp3 = temp1 + temp2
        #print(temp3)
        y = x - torch.mul(temp3,sigma)	
        #y = x - torch.mul((torch.mul(grad,F_val) + torch.mul(x,alpha) ),sigma)
        #print('Finish y')
        # Compute x
        xold = x
        #print "Finish xold"
        print (1-gamma)
        #x = torch.mul(y, (1-gamma)) + torch.mul(yLast,gamma)
	x = y        
	print (x)
        # Update gamma, lambda, and ylast
        yLast = temp
        temp = (1+np.sqrt(1+4 * lambda_s_next*lambda_s_next ) )/(2);
        lambda_s = lambda_s_next
        lambda_s_next = temp
        gamma = (1-lambda_s)/lambda_s_next
        # Update the image
        d_i = x-xold
        img=img+d_i.data
        d=d+d_i.data
    return d,img




#perturb,adv_img=NesterovGD(im,0.001,0.001,15)
    
 
def imshow(inp):
    """Imshow for Tensor."""
    inp=inp[0,:,:,:]
    #print inp
    inp = inp.numpy().transpose((1, 2, 0))
    mean = np.array([0.485, 0.456, 0.406])
    std = np.array([0.229, 0.224, 0.225])
    inp = std * inp + mean
    plt.imshow(inp)
    plt.pause(1) 


 
plt.ion()

alexnet = models.alexnet(pretrained=True)
transform=transforms.Compose([transforms.Scale(256),transforms.CenterCrop(224), transforms.ToTensor(), transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))])


data_dir = 'hymenoptera_data/val'
dset = datasets.ImageFolder(data_dir, transform)
dataloader=torch.utils.data.DataLoader(dset)
im,classes=next(iter(dataloader))


# Main Experiments.
# Do not turn this on for a lot of images!
SaveFigure = True
Result = pd.DataFrame()
ResultNewton = pd.DataFrame()
ResultLocalFool = pd.DataFrame()
# ResultDeep = pd.DataFrame()
data_dir = 'hymenoptera_data/val'
dset = datasets.ImageFolder(data_dir, transform)
dataloader=torch.utils.data.DataLoader(dset)
ImgID = 0
NewtonNormRatio = 0
LocalNormRatio = 0
NewtonRuntime = 0
LocalRuntime = 0
NewtonSuccess=0
LocalSuccess=0
alexnet.eval()
for im,classes in dataloader:
    print ImgID
    # Newtonfool
    Sigma = 0.001
    Iter = 30
    #alexnet = models.alexnet(pretrained=True)
    #random.seed(9001)
    print 'Start Newton'
    Start_Time = time.time()
    perturb,adv_img,success=NFMinNorm(im,Sigma,Iter)
    Runtime = time.time()-Start_Time
    print 'End Newton'
    a = pd.DataFrame({'ImgID':ImgID,'Image':im,'Method':'Newton','Sigma':Sigma, 'Iter':Iter,'Regular':0,'Perturb':perturb,'Class':F(Variable(im)), 'ClassPerturb':F(Variable(adv_img)),'PerturbNorm':torch.norm(perturb),'Runtime':Runtime,'ImageNorm':torch.norm(im)})
    NewtonNorm=torch.norm(perturb)/torch.norm(im)
    if success:
        NewtonSuccess=NewtonSuccess+1
        NewtonRuntime = NewtonRuntime + Runtime
        NewtonNormRatio = NewtonNormRatio + torch.norm(perturb)/torch.norm(im)
    if(SaveFigure == True):
        plt.figure(2)
        imshow(perturb)
        plt.savefig('Image'+str(ImgID)+'Newton'+'Perturb',bbox_inches='tight')
        plt.figure(2)
        imshow(adv_img)
        plt.savefig('Image'+str(ImgID)+'Newton'+'Adv_img',bbox_inches='tight')
        plt.figure(2)
        imshow(im)
        plt.savefig('Image'+str(ImgID),bbox_inches='tight')
    # Localfool
    Sigma = 0.31 
    Iter = 100
    Regular = 0.315
    #alexnet = models.alexnet(pretrained=True)
    #random.seed(9001)
    print 'Start LocalFool'
    Start_Time = time.time()
    perturb,adv_img,success=NesterovGD(im,Sigma,Regular,Iter)
    Runtime = time.time()-Start_Time
    print 'End LocalFool'
    b = pd.DataFrame({'ImgID':ImgID,'Image':im,'Method':'Local','Sigma':Sigma, 'Iter':Iter,'Regular':Regular,'Perturb':perturb,'Class':F(Variable(im)), 'ClassPerturb':F(Variable(adv_img)),'PerturbNorm':torch.norm(perturb),'Runtime':Runtime,'ImageNorm':torch.norm(im)})
    LocalNorm=torch.norm(perturb)/torch.norm(im)
    if success:
        LocalSuccess=LocalSuccess+1
        LocalRuntime = LocalRuntime + Runtime
        LocalNormRatio = LocalNormRatio + torch.norm(perturb)/torch.norm(im)
    if(SaveFigure == True):
        plt.figure(2)
        imshow(perturb)
        plt.savefig('Image'+str(ImgID)+'LocalFool'+'Perturb',bbox_inches='tight')
        plt.figure(2)
        imshow(adv_img)
        plt.savefig('Image'+str(ImgID)+'LocalFool'+'Adv_img',bbox_inches='tight')
        plt.figure(2)
        imshow(im)
        plt.savefig('Image'+str(ImgID),bbox_inches='tight')
    # Store Results
    ResultNewton = ResultNewton.append(a)	
    ResultLocalFool = ResultLocalFool.append(b)	
    ImgID = ImgID+1
    

(NewtonRuntime) = (NewtonRuntime)/NewtonSuccess
(NewtonNormRatio) = (NewtonNormRatio)/NewtonSuccess
NewtonSuccess=float(NewtonSuccess)/ImgID


(LocalRuntime) = (LocalRuntime)/LocalSuccess
(LocalNormRatio) = (LocalNormRatio)/LocalSuccess
LocalSuccess=float(NewtonSuccess)/ImgID

print (ResultNewton)
print (ResultLocalFool)
print 'Newton Runtime'
print (NewtonRuntime)
print 'Local Runtime'
print (LocalRuntime)
print 'Newton Norm Ratio'
print (NewtonNormRatio)
print 'Local Norm Ratio'
print (LocalNormRatio)
print 'Newton Success Ratio'
print (NewtonSuccess)
print 'Local Norm Ratio'
print (LocalSuccess)



# Save the results for further analysis.
ResultNewton.to_pickle('alexnet_NewtonFool')
ResultLocalFool.to_pickle('alexnet_LocalFool')
ResultNewtonGeneral = ResultNewton
ResultLocalFoolGeneral = ResultLocalFool

"""# Optimization Test
import numpy as np
from scipy.optimize import minimize
def rosen(x):
    """"""The Rosenbrock function""""""
    return sum(100.0*(x[1:]-x[:-1]**2.0)**2.0 + (1-x[:-1])**2.0)
x0 = np.array([1.3, 0.7, 0.8, 1.9, 1.2])
res = minimize(rosen, x0, method='nelder-mead',    options={'xtol': 1e-8, 'disp': True})
def TensorNorm(x):
    return torch.norm(x)
x0 = im;
res = minimize(TensorNorm, x0, method='nelder-mead',    options={'xtol': 1e-8, 'disp': True})"""
